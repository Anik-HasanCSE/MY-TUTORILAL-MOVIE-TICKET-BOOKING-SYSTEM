Features:

- [x] Create User
- [x] User Login
- [] CRUD Movies
- [] CRUD Halls
- [] CRUD Shows
- [] Book Tickets for a show
- [] View Booked Tickets
- [] Create Seat Layout for a hall
