export default function AdminDashboard() {
  return <div>AdminDashboard</div>;
}
