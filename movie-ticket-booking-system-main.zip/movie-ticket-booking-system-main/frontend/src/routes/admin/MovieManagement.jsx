export default function MovieManagement() {
  // create, update, delete movies
  return (
    <div>
      <h1>Movie Management</h1>
    </div>
  );
}
